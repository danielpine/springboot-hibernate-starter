Please post all product and debugging questions on our [forum](https://discuss.elastic.co/c/logstash). Your questions will reach our wider community members there, and if we confirm that there is a bug, then we can open a new issue here.

For all general issues, please provide the following details for fast resolution:

- Version:
- Operating System:
- Config File (if you have sensitive info, please remove it):
- Sample Data:
- Steps to Reproduce:
